const Order = require("./assignment1Order");

const OrderState = Object.freeze({
    WELCOMING: Symbol("welcoming"),
    FOOTWEAR_TYPE:Symbol("footweartype"),
    SIZE: Symbol("size"),
    COLOUR: Symbol("Colour"),
    CLEANER: Symbol("Cleaner"),
    SECOND_ITEM: Symbol("second_item"),
    SECOND_ITEM_SIZE: Symbol("second_item_size"),
    SECOND_ITEM_COLOUR: Symbol("second_item_colour"),
    SECOND_ITEM_CLEANER: Symbol("second_item_cleaner"),
    RECEIPT: Symbol("receipt")
});

module.exports = class BagsOrder extends Order {
    constructor() {
        super();
        this.stateCur = OrderState.WELCOMING;
        this.sSize = "";
        this.sColour = "";
        this.sCleaner = "";
        this.sSecondItem = "";
        this.sSecondItemSize = "";
        this.sSecondItemColour = "";
        this.sSecondItemCleaner = "";
        this.sItem = "Addidas";
        this.sSecondItem = "Sneakers";
        this.totalPrice = 0;
    }

    handleInput(sInput) {
        let aReturn = [];
        switch (this.stateCur) {
            case OrderState.WELCOMING:
                this.stateCur = OrderState.FOOTWEAR_TYPE;
                aReturn.push("Welcome to Conestoga's Shoes Company.");
                aReturn.push("What type of Shoes would you like? Please enter 1 for Addidas or 2 for Sneakers.\n1.Addidas\n2.Sneakers");
                break;

            case OrderState.FOOTWEAR_TYPE:
                if (sInput !== '1' && sInput !== '2') {
                    aReturn.push("Invalid input. Please enter 1 for Addidas or 2 for Sneakers.");
                    break;
                }
                //Here item will be shoes or sneakers based on user input(user enter 1 than shoes and 2 than sneakers)
                this.sItem = (sInput === '1') ? "Addidas" : "Sneakers";
                this.stateCur = OrderState.SIZE;
                aReturn.push(`What size would you like for ${this.sItem} shoes?\nSmall, Medium, Large`);
                break;

            case OrderState.SIZE:
                // Validate the user input for size
                if (!(sInput.toLowerCase() === 'small' || sInput.toLowerCase() === 'medium' || sInput.toLowerCase() === 'large')) {
                    aReturn.push("Invalid input. Please enter 'small', 'medium', or 'large' for the size.");
                    break;
                }

                this.stateCur = OrderState.COLOUR;
                this.sSize = sInput.toLowerCase();
                aReturn.push(`What color would you like for ${this.sItem} shoes?`);
                break;

            case OrderState.COLOUR:
                this.stateCur = OrderState.CLEANER;
                this.sColour = sInput;
                aReturn.push(`Would you like to buy socks with ${this.sItem} shoes? Please enter 'yes' or 'no'.`);
                break;

            case OrderState.CLEANER:
                if (sInput.toLowerCase() !== "no") {
                    this.sCleaner = sInput;
                }
                // If user already buy Addidas than here second item is sneakers 
                //likewise user already buy sneakers than second item Addidas and it store in SecondItem
                this.sSecondItem = (this.sItem === "Addidas") ? "Sneakers" : "Addidas";
                this.stateCur = OrderState.SECOND_ITEM;
                aReturn.push(`Would you like to add ${this.sSecondItem}? Please enter 'yes' or 'no'.`);
                break;

            case OrderState.SECOND_ITEM:
                if (sInput.toLowerCase() === "yes") {
                    this.stateCur = OrderState.SECOND_ITEM_SIZE;
                    aReturn.push(`Great choice! Please select the size for ${this.sSecondItem}`);
                } else {
                    this.isDone(true);
                    this.printReceipt(aReturn);
                    break;
                }
                break;

            case OrderState.SECOND_ITEM_SIZE:
                // Validate the user input for size of the second item
                if (!(sInput.toLowerCase() === 'small' || sInput.toLowerCase() === 'medium' || sInput.toLowerCase() === 'large')) {
                    aReturn.push("Invalid input. Please enter 'small', 'medium', or 'large' for the size.");
                    break;
                }

                this.stateCur = OrderState.SECOND_ITEM_COLOUR;
                this.sSecondItemSize = sInput.toLowerCase();
                aReturn.push(`What color would you like for the ${this.sSecondItem}?`);
                break;

            case OrderState.SECOND_ITEM_COLOUR:
                this.stateCur = OrderState.SECOND_ITEM_CLEANER;
                this.sSecondItemColour = sInput;
                aReturn.push(`Would you like to buy Insoles with the ${this.sSecondItem} shoes? Please enter 'yes' or 'no'.`);
                break;

            case OrderState.SECOND_ITEM_CLEANER:
                if (sInput.toLowerCase() !== "no") {
                    this.sSecondItemCleaner = sInput;
                }
                this.isDone(true);
                this.printReceipt(aReturn);
                break;
        }
        return aReturn;
    }
    calculateTotalPrice() {
        //Fiexd prices
        let firstItemPrice = 50;
        let cleanerPrice = 5;
        let secondItemPrice = 30;
        let secondItemCleanerPrice = 10;
        let taxRate = 0.1; // 10% tax rate

        let totalPrice = 0;

        // Add the price of the selected item
        if (this.sItem === "Addidas") {
            totalPrice += firstItemPrice;
        } else if (this.sItem === "Sneakers") {
            totalPrice += secondItemPrice; // Assuming sneakers have the same price as the second item
        }

        // Add cleaner price if selected
        if (this.sCleaner) {
            totalPrice += cleanerPrice;
        }

        // Add second item price if selected
        if (this.sSecondItem && this.stateCur === OrderState.SECOND_ITEM_CLEANER) {
            if (this.sSecondItem === "Addidas") {
                totalPrice += firstItemPrice;
            } else if (this.sSecondItem === "Sneakers") {
                totalPrice += secondItemPrice;
            }

            // Add second item cleaner price if selected
            if (this.sSecondItemCleaner) {
                totalPrice += secondItemCleanerPrice;
            }
        }

        // Calculate tax
        let tax = totalPrice * taxRate;
        let finalTotal = totalPrice + tax;

        return { actualPrice: totalPrice, tax, finalTotal };
    }

   
    printReceipt(aReturn) {
        aReturn.push("Thank you for your order!");

        // Display the prices of the items the user has bought
        if (this.sItem === "Addidas") {
            aReturn.push(`Item: ${this.sSize} ${this.sItem} with ${this.sColour} - $50`);
        } else if (this.sItem === "Sneakers") {
            aReturn.push(`Item: ${this.sSize} ${this.sItem} with ${this.sColour} - $30`);
        }

        if (this.sCleaner) {
            aReturn.push(`socks: ${this.sCleaner} - $5`);
        }

        // Display the up-sell item details if selected
        if (this.sSecondItemCleaner) {
            if (this.sSecondItemCleaner === "Insoles") {
                aReturn.push(`Up-sell Item: ${this.sSecondItemCleaner} - $10`);
            }
        }

        // Only print details of the second item if it's selected
        if (this.sSecondItem && this.stateCur === OrderState.SECOND_ITEM_CLEANER) {
            if (this.sSecondItem === "Addidas") {
                aReturn.push(`Second Item: ${this.sSecondItemSize} ${this.sSecondItem} with ${this.sSecondItemColour} - $50`);
            } else if (this.sSecondItem === "Sneakers") {
                aReturn.push(`Second Item: ${this.sSecondItemSize} ${this.sSecondItem} with ${this.sSecondItemColour} - $30`);
            }

            if (this.sSecondItemCleaner) {
                aReturn.push(`Insoles: ${this.sSecondItemCleaner} - $10`);
            }
        }

        // Display the total prices
        let { actualPrice, tax, finalTotal } = this.calculateTotalPrice();
        aReturn.push(`Actual Product Price: $${actualPrice.toFixed(2)}`);
        aReturn.push(`Tax (10%): $${tax.toFixed(2)}`);
        aReturn.push(`Final Total Price: $${finalTotal.toFixed(2)}`);

        let d = new Date();
        d.setMinutes(d.getMinutes() + 20);
        aReturn.push(`Please pick it up at ${d.toTimeString()}`);
    }
};
