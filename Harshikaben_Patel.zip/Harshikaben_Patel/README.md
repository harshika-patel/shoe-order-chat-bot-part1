# <a href="https://github.com/tonazih/Assignment1a" target="_blank">ES6 Order Bot</a>

I got the user interface for the web from a student of mine, Pat Wilken.

To run:

1. The first time run `npm install`
2. Press ctrl-f5 while your focus is in one of the files that starts with a number and is all lower case.

## Assignment 1

Create an order bot for your favourite shoes. You need to have at least 2  Shoes type  available. The options items need to have size and one other attribute like Colour. You also need an up-sell another item like Cleaner in the example.

### Marking

basic order for an item in a zip (45%)
file name : FirstName_LastName.zip (10%)
Working directory without nesting: FirstName_LastName (10%)
2nd types (up to 10%)
up-sell item other than cleaner (up to 10%)
estimated price (up to 15%)